# remove cashio saber pools 
rm ../../saber_sdk/pools/MAR1pJUGGmgS2WhSinrb4ta1F9w5mLhBXpoCX4jrSw7_saber_pool.json
rm ../../saber_sdk/pools/CSP7xvUx4mHXFHB7nGKRiGLkvkEcvo3HTTgVWJEwFTnQ_saber_pool.json
rm ../../saber_sdk/pools/CSPcADsTSETVpGAYFnb1oEc9z9qPjC987powM59bnSF3_saber_pool.json
rm ../../saber_sdk/pools/D1RyGbGF7iFupgaknywa5ThmdkdMwCJR7cQXfzTnNpFv_saber_pool.json
rm ../../saber_sdk/pools/MiMx8GQKM5CaDTCKcuK9VeTdrpEvPKR4ScyhSe4kYv1_saber_pool.json
rm ../../saber_sdk/pools/CSPC23oTm5WqmJpAR8Eo6KyQhwq8YipgHSuDcABgoSv_saber_pool.json
rm ../../saber_sdk/pools/ZUCKP2rbfTojHnuKUkzCozccxVUWR5DBTL9QbPf9YLv_saber_pool.json
rm ../../saber_sdk/pools/CASNrsSdASV1eyEca4mnEwhMqjANkyRLnF5kEGoorBX2_saber_pool.json
rm ../../saber_sdk/pools/ZoNxMdmUi6NAhBUGsBsZ751oDgqK863KXTNnQQ1HCkD_saber_pool.json
rm ../../saber_sdk/pools/FEiWZLDDFthHtFHhavYwdmF8RThgTNt8vzBqAwV4hTar_saber_pool.json